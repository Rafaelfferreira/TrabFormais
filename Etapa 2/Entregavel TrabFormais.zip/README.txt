Para utilizar o programa basta abrir o .exe e inserir o nome do arquivo no qual o automato est� contido COM A EXTENS�O (.txt)
O Automato que criamos na primeira parte do trabalho esta salvo dentro do arquivo automatop.txt

O trabalho foi feito por Rafael Ferreira, Felipe Colombelli e Daives K. Chu